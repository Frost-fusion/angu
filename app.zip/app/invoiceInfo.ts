export class invoice{
    number: number;
    date: Date;
    dueDate: Date;
    currency: string;
  }