export class bill{
    item: string;
    task: string;
    hours: number;
    rate: number;
  }