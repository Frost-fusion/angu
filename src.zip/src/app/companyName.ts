export class company{
    name: string;
    address: string;
    email: string;
    contact: number;
    privileged: boolean;
  }